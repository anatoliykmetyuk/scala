Game of Life, programmed using subscript scala code.
